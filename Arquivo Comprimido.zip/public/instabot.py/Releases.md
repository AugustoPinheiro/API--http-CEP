| Version | Description                                        |
|:-------:|:---------------------------------------------------|
| 0.5.21  | Verify configuration before start a bot            |
| 0.5.22  | Stop instabot if we have nonexistent tag in config |
| 0.5.23  | Fixed a bug: `like_followers_per_run` functionality didn't work |
| 0.5.24  | Bot stops working if like action is banned. Bot can be started again with `like_per_run: 0` configuration setting |
| 0.5.25  | Show proper error message if we have issues in getting number of user's followers |
| 0.5.26  | Show proper error message if we have issues in verifying media before commenting it |
