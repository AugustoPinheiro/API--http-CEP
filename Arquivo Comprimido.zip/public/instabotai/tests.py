import instabot

print("test")
